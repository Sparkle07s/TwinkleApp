package com.example.twinkleapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends Activity {

    private Handler handler = new Handler();
    private Runnable popRunnable;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView = findViewById(R.id.textTwinkle);
        Button heartButton = findViewById(R.id.heartButton);

        popRunnable = new Runnable() {
            @Override
            public void run() {
                ScaleAnimation scale = new ScaleAnimation(
                        1, 1.2f, 1, 1.2f,
                        ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF, 0.5f);
                scale.setDuration(500);
                scale.setRepeatCount(1);
                scale.setRepeatMode(ScaleAnimation.REVERSE);
                textView.startAnimation(scale);
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(popRunnable);

        heartButton.setOnClickListener(v -> {
            handler.removeCallbacks(popRunnable);
            startActivity(new Intent(SecondActivity.this, ThirdActivity.class));
        });
    }
}
