package com.example.twinkleapp;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class ThirdActivity extends Activity {

    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        TextView textView = findViewById(R.id.textFinal);
        textView.setText("You are my favourite person alone and thanku for rewiring my brain that I am on higher level");

        handler.postDelayed(() -> {
            textView.setText("Love You So Much 💙");
        }, 6000);

        handler.postDelayed(() -> {
            finish();
        }, 11000);
    }
}
